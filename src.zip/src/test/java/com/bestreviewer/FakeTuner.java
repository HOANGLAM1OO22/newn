package com.bestreviewer;

import java.util.*;

class FakeTuner implements Tuner {

    private int current = 0;

    private final Queue<Integer> programmedSeek = new ArrayDeque<>();

    final List<String> setCalls = new ArrayList<>();

    void setCurrent(int ch) { this.current = ch; }
    int  getCurrent()       { return current; }

    void programSeek(Integer... channels) {
        programmedSeek.clear();
        if (channels != null) programmedSeek.addAll(Arrays.asList(channels));
    }

    @Override
    public String seekCH() {
        if (programmedSeek.isEmpty()) return null;
        Integer next = programmedSeek.poll();
        if (next == null) return null;
        this.current = next;
        return Integer.toString(next);
    }

    @Override
    public void setCH(String ch) throws IllegalArgumentException {
        int v = Integer.parseInt(ch);
        if (v < 0 || v > 99) throw new IllegalArgumentException("out of range");
        this.current = v;
        setCalls.add(ch);
    }

    @Override
    public String getCurrentCH() {
        return Integer.toString(current);
    }
}
