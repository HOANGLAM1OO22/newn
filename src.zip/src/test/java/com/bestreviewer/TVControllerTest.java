
package com.bestreviewer;

import org.junit.jupiter.api.*;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class TVControllerTest {

    FakeTuner tuner;
    TVController tv;

    @BeforeEach
    void setup() {
        tuner = new FakeTuner();
        tv = new TVController(tuner);
    }

    @Test
    @DisplayName("Press 1 then OK -> channel 1")
    void singleDigitThenOk() {
        tv.pushButton(remoteKey.KEY_1);
        tv.pushButton(remoteKey.KEY_OK);
        assertEquals(1, Integer.parseInt(tuner.getCurrentCH()));
        assertEquals(Collections.singletonList("1"), tuner.setCalls);
    }

    @Test
    @DisplayName("Press 1 2 -> immediate to 12")
    void twoDigitsImmediate() {
        tv.pushButton(remoteKey.KEY_1);
        tv.pushButton(remoteKey.KEY_2);
        assertEquals(12, tuner.getCurrent());
        assertEquals(Collections.singletonList("12"), tuner.setCalls);
        assertEquals("", tv.getPendingBuffer()); // buffer cleared
    }

    @Test
    @DisplayName("1 2 3 4 -> 12 then 34")
    void fourDigitsBecomeTwoPairs() {
        tv.pushButton(remoteKey.KEY_1);
        tv.pushButton(remoteKey.KEY_2);
        tv.pushButton(remoteKey.KEY_3);
        tv.pushButton(remoteKey.KEY_4);
        assertEquals(34, tuner.getCurrent());
        assertEquals(Arrays.asList("12", "34"), tuner.setCalls);
    }

    @Test
    @DisplayName("4 5 6 -> become 45, pending '6'; OK -> 6")
    void threeDigitsThenOkForSingle() {
        tv.pushButton(remoteKey.KEY_4);
        tv.pushButton(remoteKey.KEY_5);
        tv.pushButton(remoteKey.KEY_6);
        assertEquals(45, tuner.getCurrent());
        assertEquals("6", tv.getPendingBuffer());
        tv.pushButton(remoteKey.KEY_OK);
        assertEquals(6, tuner.getCurrent());
        assertEquals(Arrays.asList("45", "6"), tuner.setCalls);
        assertEquals("", tv.getPendingBuffer());
    }

    @Test
    @DisplayName("Pending 6 + digit 7 -> 67")
    void pendingThenAnotherDigit() {
        tv.pushButton(remoteKey.KEY_4);
        tv.pushButton(remoteKey.KEY_5);
        tv.pushButton(remoteKey.KEY_6);
        tv.pushButton(remoteKey.KEY_7);
        assertEquals(67, tuner.getCurrent());
        assertEquals(Arrays.asList("45", "67"), tuner.setCalls);
    }

    @Test
    @DisplayName("0 then 7 -> channel 7 (leading zero ignored)")
    void leadingZeroThenDigit() {
        tv.pushButton(remoteKey.KEY_0);
        tv.pushButton(remoteKey.KEY_7);
        assertEquals(7, tuner.getCurrent());
        assertEquals(Collections.singletonList("7"), tuner.setCalls);
    }

    @Test
    @DisplayName("Other button invalidates pending buffer")
    void otherButtonsInvalidateBuffer() {
        tuner.setCurrent(10);
        tv.pushButton(remoteKey.KEY_6);
        tv.pushButton(remoteKey.KEY_UP);
        assertEquals(11, tuner.getCurrent());
        assertEquals("", tv.getPendingBuffer());
    }

    @Test
    @DisplayName("Preferred toggle adds then removes (sorted)")
    void preferredToggle() {
        tuner.setCurrent(12);
        tv.pushButton(remoteKey.KEY_PREFERRED_TOGGLE);
        Set<Integer> prefs = tv.getPreferredChannels();
        assertTrue(prefs.contains(12));

        tv.pushButton(remoteKey.KEY_PREFERRED_TOGGLE);
        assertFalse(tv.getPreferredChannels().contains(12));
    }

    @Test
    @DisplayName("Next preferred: go to next greater; wrap to smallest")
    void nextPreferredWraps() {
        tuner.setCurrent(1);
        tv.pushButton(remoteKey.KEY_PREFERRED_TOGGLE);
        tuner.setCurrent(4);
        tv.pushButton(remoteKey.KEY_PREFERRED_TOGGLE);
        tuner.setCurrent(12);
        tv.pushButton(remoteKey.KEY_PREFERRED_TOGGLE);
        tuner.setCurrent(56);
        tv.pushButton(remoteKey.KEY_PREFERRED_TOGGLE);

        tuner.setCurrent(6);
        tv.pushButton(remoteKey.KEY_NEXT_PREFERRED);
        assertEquals(12, tuner.getCurrent());

        tuner.setCurrent(56);
        tv.pushButton(remoteKey.KEY_NEXT_PREFERRED);
        assertEquals(1, tuner.getCurrent());
    }

    @Test
    @DisplayName("Seek stores all viewable channels (sorted unique)")
    void seekStoresChannels() {
        tuner.setCurrent(78);
        tuner.programSeek(83, 95, 4);
        tv.pushButton(remoteKey.KEY_SEEK);

        assertEquals(Arrays.asList(4, 83, 95), tv.getSeekChannels());
        assertEquals(4, tuner.getCurrent());
    }

    @Test
    @DisplayName("Up/Down without seek list: +/-1 with wrap")
    void upDownNoSeek() {
        tuner.setCurrent(6);
        tv.pushButton(remoteKey.KEY_UP);
        assertEquals(7, tuner.getCurrent());

        tv.pushButton(remoteKey.KEY_DOWN);
        assertEquals(6, tuner.getCurrent());

        tuner.setCurrent(99);
        tv.pushButton(remoteKey.KEY_UP);
        assertEquals(0, tuner.getCurrent());

        tuner.setCurrent(0);
        tv.pushButton(remoteKey.KEY_DOWN);
        assertEquals(99, tuner.getCurrent());
    }

    @Test
    @DisplayName("Up/Down with seek list uses stored channels")
    void upDownWithSeekList() {
        tuner.programSeek(4, 6, 14, 93);
        tv.pushButton(remoteKey.KEY_SEEK);
        assertEquals(Arrays.asList(4, 6, 14, 93), tv.getSeekChannels());

        tuner.setCurrent(6);
        tv.pushButton(remoteKey.KEY_UP);
        assertEquals(14, tuner.getCurrent());
        tv.pushButton(remoteKey.KEY_DOWN);
        assertEquals(6, tuner.getCurrent());
        tv.pushButton(remoteKey.KEY_DOWN);
        assertEquals(4, tuner.getCurrent());

        tuner.setCurrent(95);
        tv.pushButton(remoteKey.KEY_UP);
        assertEquals(4, tuner.getCurrent());
        tv.pushButton(remoteKey.KEY_DOWN);
        assertEquals(93, tuner.getCurrent());

        tuner.setCurrent(0);
        tv.pushButton(remoteKey.KEY_UP);
        assertEquals(4, tuner.getCurrent());
        tv.pushButton(remoteKey.KEY_DOWN);
        assertEquals(93, tuner.getCurrent());
    }

    @Test
    @DisplayName("OK with empty buffer does nothing")
    void okWithoutBufferDoesNothing() {
        tuner.setCurrent(12);
        tv.pushButton(remoteKey.KEY_OK);
        assertEquals(12, tuner.getCurrent());
    }

    @Test
    @DisplayName("Reject invalid set channel (<0 or >99)")
    void rejectInvalidChannel() {
        assertThrows(IllegalArgumentException.class, () -> tuner.setCH("100"));
        assertThrows(IllegalArgumentException.class, () -> tuner.setCH("-1"));
    }

}
