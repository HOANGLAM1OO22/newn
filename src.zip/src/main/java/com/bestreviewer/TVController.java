
package com.bestreviewer;

import java.util.*;

public class TVController {

    private final Tuner tuner;

    private String inputBuffer = "";

    private final List<Integer> seekChannels = new ArrayList<>();

    private final TreeSet<Integer> preferredChannels = new TreeSet<>();

    public TVController(Tuner tuner) {
        this.tuner = Objects.requireNonNull(tuner);
    }

    public void pushButton(remoteKey key) {
        if (remoteKey.isDigit(key)) {
            onDigit(remoteKey.toDigit(key));
            return;
        }
        switch (key) {
            case KEY_OK:
                onOk();
                return;
            case KEY_UP:
                invalidateBuffer();
                channelUp();
                return;
            case KEY_DOWN:
                invalidateBuffer();
                channelDown();
                return;
            case KEY_SEEK:
                invalidateBuffer();
                performSeek();
                return;
            case KEY_PREFERRED_TOGGLE:
                invalidateBuffer();
                togglePreferred();
                return;
            case KEY_NEXT_PREFERRED:
                invalidateBuffer();
                gotoNextPreferred();
                return;
            default:
                invalidateBuffer();
        }
    }

    private void onDigit(int d) {
        if (inputBuffer.isEmpty()) {
            inputBuffer = Integer.toString(d);   // allow "0"
            return;
        }
        int first = Integer.parseInt(inputBuffer);
        int twoDigit = (first == 0) ? d : (first * 10 + d);
        setChannel(twoDigit);

        inputBuffer = "";
    }

    private void onOk() {
        if (inputBuffer.isEmpty()) return;
        int ch = Integer.parseInt(inputBuffer);
        setChannel(ch);
        inputBuffer = "";
    }

    private void invalidateBuffer() {
        inputBuffer = "";
    }

    private void channelUp() {
        if (seekChannels.isEmpty()) {
            int next = (getCurrentChannel() + 1) % 100;
            setChannel(next);
        } else {
            int next = nextFromSeekList(getCurrentChannel());
            setChannel(next);
        }
    }

    private void channelDown() {
        if (seekChannels.isEmpty()) {
            int prev = (getCurrentChannel() + 99) % 100; // wrap 0->99
            setChannel(prev);
        } else {
            int prev = prevFromSeekList(getCurrentChannel());
            setChannel(prev);
        }
    }

    private void performSeek() {
        seekChannels.clear();
        Set<Integer> found = new HashSet<>();
        while (true) {
            String s = tuner.seekCH();
            if (s == null) break;
            int ch = parseChannel(s);
            if (ch >= 0 && ch <= 99) {
                found.add(ch);
            }
        }
        seekChannels.addAll(found);
        Collections.sort(seekChannels);
    }

    private void togglePreferred() {
        int cur = getCurrentChannel();
        if (preferredChannels.contains(cur)) {
            preferredChannels.remove(cur);
        } else {
            preferredChannels.add(cur);
        }
    }

    private void gotoNextPreferred() {
        if (preferredChannels.isEmpty()) return;
        int cur = getCurrentChannel();
        Integer higher = preferredChannels.higher(cur);
        int next = (higher != null) ? higher : preferredChannels.first();
        setChannel(next);
    }

    private int getCurrentChannel() {
        return parseChannel(tuner.getCurrentCH());
    }

    private static int parseChannel(String ch) {
        try {
            return Integer.parseInt(ch);
        } catch (Exception e) {
            throw new IllegalStateException("Tuner returned non-numeric channel: " + ch, e);
        }
    }

    private void setChannel(int ch) {
        if (ch < 0 || ch > 99) throw new IllegalArgumentException("Channel out of range: " + ch);
        tuner.setCH(Integer.toString(ch));
    }

    private int nextFromSeekList(int cur) {
        for (int v : seekChannels) {
            if (v > cur) return v;
        }
        return seekChannels.get(0);
    }

    private int prevFromSeekList(int cur) {
        for (int i = seekChannels.size() - 1; i >= 0; --i) {
            int v = seekChannels.get(i);
            if (v < cur) return v;
        }
        return seekChannels.get(seekChannels.size() - 1);
    }

    public List<Integer> getSeekChannels() {
        return Collections.unmodifiableList(seekChannels);
    }

    public Set<Integer> getPreferredChannels() {
        return Collections.unmodifiableSet(preferredChannels);
    }

    public String getPendingBuffer() {
        return inputBuffer;
    }
}
