
package com.bestreviewer;

public enum remoteKey {
    KEY_0("0"),
    KEY_1("1"),
    KEY_2("2"),
    KEY_3("3"),
    KEY_4("4"),
    KEY_5("5"),
    KEY_6("6"),
    KEY_7("7"),
    KEY_8("8"),
    KEY_9("9"),

    KEY_OK("OK"),
    KEY_UP("UP"),
    KEY_DOWN("DOWN"),
    KEY_SEEK("SEEK"),
    KEY_PREFERRED_TOGGLE("PREF_TOGGLE"),
    KEY_NEXT_PREFERRED("NEXT_PREF");

    private final String key;
    remoteKey(String key) { this.key = key; }
    @Override public String toString() { return key; }

    public static boolean isDigit(remoteKey k) {
        return k == KEY_0 || k == KEY_1 || k == KEY_2 || k == KEY_3 || k == KEY_4
                || k == KEY_5 || k == KEY_6 || k == KEY_7 || k == KEY_8 || k == KEY_9;
    }

    public static int toDigit(remoteKey k) {
        switch (k) {
            case KEY_0: return 0;
            case KEY_1: return 1;
            case KEY_2: return 2;
            case KEY_3: return 3;
            case KEY_4: return 4;
            case KEY_5: return 5;
            case KEY_6: return 6;
            case KEY_7: return 7;
            case KEY_8: return 8;
            case KEY_9: return 9;
            default: throw new IllegalArgumentException("Not a digit key: " + k);
        }
    }
}
