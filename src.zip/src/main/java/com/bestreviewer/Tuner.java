

package com.bestreviewer;

public interface Tuner {
    public String seekCH();
    public void setCH(String ch) throws IllegalArgumentException;
    public String getCurrentCH();
}
